sudo /usr/bin/pikeyd165 -d
emulationstation #auto