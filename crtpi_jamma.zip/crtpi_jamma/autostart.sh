sudo chmod a+rwx /dev/uinput
sudo -s pikeyd165 -smi -ndb -d &> /dev/null
emulationstation #auto