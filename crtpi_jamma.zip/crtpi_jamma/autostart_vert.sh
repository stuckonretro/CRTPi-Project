sudo /usr/bin/pikeyd165 -d
emulationstation --resolution 240 320 --screenrotate 3 #auto