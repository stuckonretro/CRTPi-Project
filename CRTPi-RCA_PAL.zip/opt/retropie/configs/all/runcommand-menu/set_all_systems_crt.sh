cp /opt/retropie/configs/arcade/retroarch_crt.cfg /opt/retropie/configs/arcade/retroarch.cfg > /dev/null
cp /opt/retropie/configs/atari800/retroarch_crt.cfg /opt/retropie/configs/atari800/retroarch.cfg > /dev/null
cp /opt/retropie/configs/atari2600/retroarch_crt.cfg /opt/retropie/configs/atari2600/retroarch.cfg > /dev/null
cp /opt/retropie/configs/atari5200/retroarch_crt.cfg /opt/retropie/configs/atari5200/retroarch.cfg > /dev/null
cp /opt/retropie/configs/atari7800/retroarch_crt.cfg /opt/retropie/configs/atari7800/retroarch.cfg > /dev/null
default=`cat /opt/retropie/configs/atarilynx/default`; cp /opt/retropie/configs/atarilynx/retroarch_$default.cfg /opt/retropie/configs/atarilynx/retroarch.cfg > /dev/null
cp /opt/retropie/configs/coleco/retroarch_crt.cfg /opt/retropie/configs/coleco/retroarch.cfg > /dev/null
cp /opt/retropie/configs/fds/retroarch_crt.cfg /opt/retropie/configs/fds/retroarch.cfg > /dev/null
default=`cat /opt/retropie/configs/gamegear/default`; cp /opt/retropie/configs/gamegear/retroarch_$default.cfg /opt/retropie/configs/gamegear/retroarch.cfg > /dev/null
default=`cat /opt/retropie/configs/gb/default`; cp /opt/retropie/configs/gb/retroarch_$default.cfg /opt/retropie/configs/gb/retroarch.cfg > /dev/null
default=`cat /opt/retropie/configs/gba/default`; cp /opt/retropie/configs/gba/retroarch_$default.cfg /opt/retropie/configs/gba/retroarch.cfg > /dev/null
default=`cat /opt/retropie/configs/gbc/default`; cp /opt/retropie/configs/gbc/retroarch_$default.cfg /opt/retropie/configs/gbc/retroarch.cfg > /dev/null
cp /opt/retropie/configs/intellivision/retroarch_crt.cfg /opt/retropie/configs/intellivision/retroarch.cfg > /dev/null
cp /opt/retropie/configs/mastersystem/retroarch_crt.cfg /opt/retropie/configs/mastersystem/retroarch.cfg > /dev/null
cp /opt/retropie/configs/megadrive/retroarch_crt.cfg /opt/retropie/configs/megadrive/retroarch.cfg > /dev/null
cp /opt/retropie/configs/msx/retroarch_crt.cfg /opt/retropie/configs/msx/retroarch.cfg > /dev/null
cp /opt/retropie/configs/n64/retroarch_crt.cfg /opt/retropie/configs/n64/retroarch.cfg > /dev/null
cp /opt/retropie/configs/neogeo/retroarch_crt.cfg /opt/retropie/configs/neogeo/retroarch.cfg > /dev/null
cp /opt/retropie/configs/nes/retroarch_crt.cfg /opt/retropie/configs/nes/retroarch.cfg > /dev/null
default=`cat /opt/retropie/configs/ngp/default`; cp /opt/retropie/configs/ngp/retroarch_$default.cfg /opt/retropie/configs/ngp/retroarch.cfg > /dev/null
default=`cat /opt/retropie/configs/ngpc/default`; cp /opt/retropie/configs/ngpc/retroarch_$default.cfg /opt/retropie/configs/ngpc/retroarch.cfg > /dev/null
cp /opt/retropie/configs/pc/retroarch_crt.cfg /opt/retropie/configs/pc/retroarch.cfg > /dev/null
cp /opt/retropie/configs/pc98/retroarch_crt.cfg /opt/retropie/configs/pc98/retroarch.cfg > /dev/null
cp /opt/retropie/configs/pce-cd/retroarch_crt.cfg /opt/retropie/configs/pce-cd/retroarch.cfg > /dev/null
cp /opt/retropie/configs/pcengine/retroarch_crt.cfg /opt/retropie/configs/pcengine/retroarch.cfg > /dev/null
cp /opt/retropie/configs/ports/cavestory/retroarch_crt.cfg /opt/retropie/configs/ports/cavestory/retroarch.cfg > /dev/null
cp /opt/retropie/configs/ports/doom/retroarch_crt.cfg /opt/retropie/configs/ports/doom/retroarch.cfg > /dev/null
cp /opt/retropie/configs/ports/quake/retroarch_crt.cfg /opt/retropie/configs/ports/quake/retroarch.cfg > /dev/null
cp /opt/retropie/configs/psx/retroarch_crt.cfg /opt/retropie/configs/psx/retroarch.cfg > /dev/null
cp /opt/retropie/configs/sega32x/retroarch_crt.cfg /opt/retropie/configs/sega32x/retroarch.cfg > /dev/null
cp /opt/retropie/configs/segacd/retroarch_crt.cfg /opt/retropie/configs/segacd/retroarch.cfg > /dev/null
cp /opt/retropie/configs/sg-1000/retroarch_crt.cfg /opt/retropie/configs/sg-1000/retroarch.cfg > /dev/null
cp /opt/retropie/configs/snes/retroarch_crt.cfg /opt/retropie/configs/snes/retroarch.cfg > /dev/null
default=`cat /opt/retropie/configs/wonderswan/default`; cp /opt/retropie/configs/wonderswan/retroarch_$default.cfg /opt/retropie/configs/wonderswan/retroarch.cfg > /dev/null
default=`cat /opt/retropie/configs/wonderswancolor/default`; cp /opt/retropie/configs/wonderswancolor/retroarch_$default.cfg /opt/retropie/configs/wonderswancolor/retroarch.cfg > /dev/null
cp /opt/retropie/configs/zxspectrum/retroarch_crt.cfg /opt/retropie/configs/zxspectrum/retroarch.cfg > /dev/null
exit 1