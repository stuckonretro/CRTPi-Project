echo border > /opt/retropie/configs/atarilynx/default; cp /opt/retropie/configs/atarilynx/retroarch_720_border.cfg /opt/retropie/configs/atarilynx/retroarch.cfg > /dev/null
echo border > /opt/retropie/configs/gamegear/default; cp /opt/retropie/configs/gamegear/retroarch_720_border.cfg /opt/retropie/configs/gamegear/retroarch.cfg > /dev/null
echo border > /opt/retropie/configs/gb/default; cp /opt/retropie/configs/gb/retroarch_720_border.cfg /opt/retropie/configs/gb/retroarch.cfg > /dev/null
echo border > /opt/retropie/configs/gba/default; cp /opt/retropie/configs/gba/retroarch_720_border.cfg /opt/retropie/configs/gba/retroarch.cfg > /dev/null
echo border > /opt/retropie/configs/gbc/default; cp /opt/retropie/configs/gbc/retroarch_720_border.cfg /opt/retropie/configs/gbc/retroarch.cfg > /dev/null
echo border > /opt/retropie/configs/ngp/default; cp /opt/retropie/configs/ngp/retroarch_720_border.cfg /opt/retropie/configs/ngp/retroarch.cfg > /dev/null
echo border > /opt/retropie/configs/ngpc/default; cp /opt/retropie/configs/ngpc/retroarch_720_border.cfg /opt/retropie/configs/ngpc/retroarch.cfg > /dev/null
cp /opt/retropie/configs/wonderswan/retroarch_hdmi.cfg /opt/retropie/configs/wonderswan/retroarch.cfg > /dev/null
cp /opt/retropie/configs/wonderswancolor/retroarch_hdmi.cfg /opt/retropie/configs/wonderswancolor/retroarch.cfg > /dev/null
exit 1