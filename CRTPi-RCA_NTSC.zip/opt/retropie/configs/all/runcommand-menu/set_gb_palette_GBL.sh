cp /home/pi/RetroPie/BIOS/palettes/GBL.pal /home/pi/RetroPie/BIOS/palettes/default.pal > /dev/null
exit 1